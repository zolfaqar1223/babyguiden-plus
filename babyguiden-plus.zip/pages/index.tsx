import React from 'react';

export default function Home() {
  return (
    <div>
      <h1>Welcome to BabyGuiden+</h1>
      <p>This is your starter app – ready for onboarding, tracking and AI-chat.</p>
    </div>
  );
}
